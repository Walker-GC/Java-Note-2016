# 3. IOC (Inversion Of Controll 控制反转)
## IOC是什么? 
对象之间的依赖关系由容器来建立。<br/>
## DI是什么(Dependency Injection 依赖注入)?
容器可以通过调用对象提供的set方法或者构造器来建立
依赖关系。<br/>
(1) 采用set方法来注入 <br/>
![set](set.png)
![set](set2.png)
(2) 构造器注入 <br/>
![set](cons.png)
## 自动装配 (了解)
(1) 默认情况下，容器不会自动装配。<br/>
(2) 可以设置autowire属性值来让容器依据某种规则 
进行自动装配。<br/>
 byName：容器查找bean的id与属性名一致的bean,然后
调用set方法来完成注入。<br/>
![set](byName.png)
<br/>
 byType:容器查找与属性类型一致的bean,然后调用set方
法来完成注入。注：如果找到多个，则报错。<br/>
 constructor:容器查找与属性类型一致的bean,然后调用
构造器来完成注入。<br/>
## 注入基本类型的值
使用value属性来注入。
## 注入集合类型的值
List
Set
Map
Properties
## 引用方式注入集合类型的值
![set](listBean.png)
## spring表达式
使用spring表达式读取其它bean的属性值。<br/>
![set](spel.png)


 


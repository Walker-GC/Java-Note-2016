package autowire;

public class Waiter {

	public Waiter() {
		System.out.println("Waiter()");
	}
	
}

package cn.tedu.entity;

public class User {
	
}

# Spring

## AOP

AOP 的优点：

在不改变原有程序的情况下插入（扩展）出功能，一般都是切向（横截面）功能。

用途： 切向（横截面）功能扩展： 日志，功能审计，性能追踪等。

### 通知

用于表示切面程序相对以被拦截方法的调用位置

如：

![](1.png)

@Before 在业务方法之前调用

@AfterReturning 在业务方法正常（没有异常）结束以后调用

@AfterThrowing 在业务方法出现以后异常调用

@Arter 无论业务方法是否出现异常，都会调用

@Around 在业务方法周围调用

案例：

	@Before("bean(userService)")
	public void before(){
		System.out.println("Before");
	}
	
	@AfterReturning("bean(userService)")
	public void afterReturning(){
		System.out.println("AfterReturning");
	}
	
	@AfterThrowing(pointcut="bean(userService)"
			,throwing="ex")
	public void afterThrowing(Exception ex)
		throws Exception{
		System.out.println("AfterThrowing");
		throw ex;
	}
	
	@After("bean(userService)")
	public void after(){
		System.out.println("After");
	}
	
	//环绕
	@Around("bean(*Service)")
	public Object around(
			ProceedingJoinPoint joinPoint)	
			throws Throwable{
		System.out.println("开始");
		//调用业务方法
		Signature m=joinPoint.getSignature();
		System.out.println(m);//输出方法签名
		Object value=joinPoint.proceed();
		System.out.println("结束");
		return value;//业务方法的返回值
	}

> 提示：	@Around 中joinPoint是连接点对象，调用joinPoint.proceed()，可以执行后续业务方法，joinPoint.getSignature()可以获取当前调用方法的签名信息。

### 切入点（织入位置）

是将AOP组件织入到哪个类的那个方法。

> 提示：找到方法以后，在方法的前后位置由 “通知” 决定

Bean 组件 
	
	bean(组件ID)

## 声明式事务管理

事务：保护原子性业务操作，保证这个操作一次完成，或者在出现故障时候回退。不能出现中间状态。

程序控制事务：

	try{
		开启事务
		事务业务操作
		事务业务操作
		事务业务操作
		提交事务
	}catch(Exception e){
		回滚事务
	}finally{
		释放资源
	}
	
Spring 利用 AOP 技术实现了 声明式事务处理。无需编程即可控制程序中的事务！只需要添加 事务 注解即可！！大大简化了事务程序开发。

	
使用声明式事务：	

	@Transactional
	public Object 业务方法(){
		业务过程
		添加数据
		删除数据
		修改数据
		添加数据
	}

> 基本规则: 业务方法的整体看做一个事务，如果业务方法正常结束（没有异常），则业务完整提交。如果业务过程中抛出任何异常，正业务过程整体回滚，回滚到业务方法运行之前的情况。

案例：

	deleteAll(id1, id2, id3, id4, id5, id6)
	
	//业务接口方法
	void deleteAll(String... noteId);
	
	//业务接口实现
	@Transactional
	void deleteAll(String... noteId){
		noteId 就是数组
	}

> 变长参数就是数组，String... String[] 一样













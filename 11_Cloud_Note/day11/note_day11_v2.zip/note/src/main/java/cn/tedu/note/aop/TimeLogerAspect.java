package cn.tedu.note.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * 记录每个业务方法的执行时间
 * 保存到文件中 
 */
@Component
@Aspect
public class TimeLogerAspect {


	@Around("execution(* cn.tedu.note.service.*Service.*(..))")
	public Object proc(
		ProceedingJoinPoint joinPoint)
		throws Throwable{
		long t1=System.nanoTime();
		Object val = joinPoint.proceed();
		long t2=System.nanoTime();
		Signature s=joinPoint.getSignature();
		System.out.println(
			System.currentTimeMillis()+":"+
			s+":"+(t2-t1));
		return val;
	}
}







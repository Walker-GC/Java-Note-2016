package cn.tedu.demo;

public class TestCase {
	
	public void testHello(){
		System.out.println("Hello");
	}
	
	public void testTom(){
		System.out.println("Tom");
	}
	
	public void testJerry(){
		System.out.println("Jerry"); 
	}
	
	public void testOK(String msg){
		System.out.println(msg); 
	}
}

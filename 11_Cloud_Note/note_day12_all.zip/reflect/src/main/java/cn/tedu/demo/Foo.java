package cn.tedu.demo;

public class Foo {

	public Foo() {
	}
	
	public void who(){
		System.out.println("Hi");
	}

	private void test(int n){
		System.out.println(n); 
	}
	
	private void test(String s, int n){
		System.out.println(s+n); 
	}
	
	
}

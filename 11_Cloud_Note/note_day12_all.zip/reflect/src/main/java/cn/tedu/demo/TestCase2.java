package cn.tedu.demo;

public class TestCase2 {
	
	@Test
	public void hello(){
		System.out.println("Hello");
	}
	
	@Test
	public void kitty(){
		System.out.println("Kitty"); 
	}
}

package cn.tedu.demo;

public class Goo {
	
	private int num = 5;

	public Goo() {
	}

}

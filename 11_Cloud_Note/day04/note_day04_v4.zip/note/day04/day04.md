# 云笔记



## 密码的加密处理

业界原则： 密码不能明文保存！！！

> 明文： 原始数据， 密文：原始数据经过计算得到的加密数据

### 消息摘要技术

常用算法： MD5  SHA-1 等

消息摘要结果特定: 

1. 同样数据的摘要结果一定相同
2. 摘要结果一样，其数据一定一样

![](md5.png)

如：

	md5sum readme.txt passwd.csv nexus.conf.tar.gz

	4983b761596da1a8296a5e16d94a5f75  readme.txt
	235d83751c25c8227617a8255bebd3ed  passwd.csv
	525d172647acf4d1879327e0c5d7276a  nexus.conf.tar.gz

摘要用途: 验证数据的完整性

### 利用摘要加密密码

直接摘要存储：

原理：

![](1.png)

> 缺点：简单摘要不能解决被反查问题，可以在一些网站上反查简单数据的摘要。

加盐摘要：

原理：

![](2.png)

> 可以避免被反查

实现密码加密：

导入 Commons-codec 包

	<dependency>
		<groupId>commons-codec</groupId>
		<artifactId>commons-codec</artifactId>
		<version>1.10</version>
	</dependency>

测试：

	@Test
	public void testMd5(){
		String str = "12345678你好";
		String md5 = 
			DigestUtils.md5Hex(str);
		System.out.println(md5); 
	}
	
	@Test
	public void testSaltPwd()
		throws Exception {
		String pwd = "123";
		String salt = "你吃了吗？";
		String s = 
			DigestUtils.md5Hex(pwd+salt);
		System.out.println(s);
		//2625eadfbe7fa3168f8e9cafa28aaa44
		
		//update cn_user set cn_user_password = 
		// '2625eadfbe7fa3168f8e9cafa28aaa44'
	}

将数据中的全部密码重置为123：

	update cn_user set cn_user_password=	 '2625eadfbe7fa3168f8e9cafa28aaa44';
	
添加加密工具类：

	public class Utils {
		
		private static final String salt = 
				"你吃了吗？";
		
		public static String crypt(String pwd){
			return DigestUtils.md5Hex(pwd+salt);
		}
	}

更新登录算法 UserServiceImpl 的 login 方法：

	//比较摘要
	String md5=Utils.crypt(password);
	System.out.println(md5);
	System.out.println(user);
	if(user.getPassword().equals(md5)){
		//业务处理
		//登录成功，返回用户信息
		return user;
	}

测试：用户可以正常登录。

**经典面试题**: 是否可以在Cookie中保存密码等敏感信息

答案： 不能直接明文保存密码等敏感信息到Cookie，如果实在需要保存可以进行加盐摘要处理以后再保存到cookies中。













